﻿
internal class Program
{
    static
        float[] notes = {16.35f, 18.35f,
        20.60f,21.83f,
        24.5f,27.5f,30.87f,
    };
    static string song = "c4e c4e g4e g4e a4e a4e g4e f4e f4e e4e e4e d4e d4e c4e g4e g4e f4e f4e e4e e4e d4e c4e g4e g4e a4e g4e f4e f4e e4e e4e d4e c4e";
    static void mygudsong(char note, int oct, char dur)
    {
        float frequency;
        switch (note)

        {
            case 'c':
                frequency = notes[0];
                break;
            case 'd':
                frequency = notes[1];
                break;
            case 'e':
                frequency = notes[2];
                break;
            case 'f':
                frequency = notes[3];
                break;
            case 'g':
                frequency = notes[4];
                break;
            case 'b':
                frequency = notes[5];
                break;
            case 'a':
                frequency = notes[6];
                break;
            default:
                frequency = 0;
                break;

        }
        int delay = 0;
        for (int i = 0; i < oct; i++)
        {
            frequency *= 2;

        }

        switch (dur)
        {
            case 'e':
                delay = 125;
                break;
            case 'a':
                delay = 300;
                break;
            case 'c':
                delay = 250;
                break;
            case 'f':
                delay = 200;
                break;
            case 'g':
                delay = 150;
                break;
            case 'b':
                delay = 100;
                break;
            case 'w':
                delay = 1000;
                break;
            case 'h':
                delay = 500;
                break;
        }
        if (frequency > 36 && frequency < 32000)
            Console.Beep((int)frequency, delay);
        else
        {
            DateTime target = DateTime.Now.AddMilliseconds(delay);
            while (DateTime.Now <= target) ;
        }
    }
    private static void Main(string[] args)
    {
        do
        {


            song = Console.ReadLine();

            for (int i = 0; i < song.Length; i += 4)
            {
                string s = (song.Substring(i + 1, 1));
                mygudsong(song[i],
                    int.Parse(s),
                    song[i + 2]); ;
            }
        } while (song != "");
    }
}
